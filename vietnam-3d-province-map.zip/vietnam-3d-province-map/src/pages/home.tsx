import { useCallback, useEffect, useId, useMemo, useRef, useState } from "react";
import * as THREE from "three";
import { ArrowLeft, Lock, LockOpen, RotateCcw } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Slider } from "@/components/ui/slider";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { ToggleGroup, ToggleGroupItem } from "@/components/ui/toggle-group";
import { CITIES, LAND } from "@/data/vietnam";
import { elevation, terrainColor, TERRAIN_LEGEND } from "@/data/terrain";
import { METRICS, RAMP, classOf, quantileBreaks, statsFor, type MetricKey } from "@/data/stats";

type MetricChoice = MetricKey | "none";

/* ------------------------------------------------------------------ */
/* Effect settings                                                     */
/* ------------------------------------------------------------------ */

type Viz = "prism" | "bars" | "bubbles";
type LabelMode = "none" | "top5" | "all";

const VIZ_OPTIONS: { value: Viz; label: string }[] = [
  { value: "prism", label: "Raised areas" },
  { value: "bars", label: "3D bars" },
  { value: "bubbles", label: "Bubbles" },
];

type Settings = {
  lift: number;
  pop: number;
  push: number;
  fade: number;
  speed: number;
  wobble: number;
  height: number;
  exag: number;
  gap: number;
  valueHeight: number;
  viz: Viz;
  labels: LabelMode;
  showAverage: boolean;
  autoRotate: boolean;
  lockOnClick: boolean;
  cinematic: boolean;
};

const DEFAULTS: Settings = {
  lift: 5,
  pop: 1.2,
  push: 1.5,
  fade: 0.55,
  speed: 8,
  wobble: 0.3,
  height: 0.25,
  exag: 1,
  gap: 0.12,
  valueHeight: 10,
  viz: "prism",
  labels: "top5",
  showAverage: true,
  autoRotate: false,
  lockOnClick: true,
  cinematic: true,
};

type NumKey = Exclude<keyof Settings, "autoRotate" | "lockOnClick" | "cinematic" | "viz" | "labels" | "showAverage" | "valueHeight">;

const SLIDERS: { key: NumKey; label: string; min: number; max: number; step: number; fmt: (v: number) => string }[] = [
  { key: "lift", label: "Lift height", min: 0, max: 15, step: 0.5, fmt: (v) => v.toFixed(1) },
  { key: "pop", label: "Pop scale", min: 1, max: 1.8, step: 0.05, fmt: (v) => `${v.toFixed(2)}×` },
  { key: "push", label: "Push neighbours apart", min: 0, max: 6, step: 0.25, fmt: (v) => v.toFixed(2) },
  { key: "fade", label: "Fade rest of country", min: 0, max: 0.9, step: 0.05, fmt: (v) => `${Math.round(v * 100)}%` },
  { key: "speed", label: "Animation speed", min: 1, max: 25, step: 1, fmt: (v) => `${v}` },
  { key: "wobble", label: "Wobble", min: 0, max: 1, step: 0.05, fmt: (v) => v.toFixed(2) },
  { key: "height", label: "Base thickness", min: 0.05, max: 2, step: 0.05, fmt: (v) => v.toFixed(2) },
  { key: "exag", label: "Elevation exaggeration", min: 0, max: 2.5, step: 0.05, fmt: (v) => `×${Math.round(v * 27.75)}` },
  { key: "gap", label: "Tile gap", min: 0, max: 0.5, step: 0.02, fmt: (v) => `${Math.round(v * 100)}%` },
];

/* ------------------------------------------------------------------ */
/* Geometry helpers                                                    */
/* ------------------------------------------------------------------ */

const LON0 = 105.8;
const LAT0 = 15.9;
const SCALE = 4;
const COS = Math.cos((16 * Math.PI) / 180);
const DETAIL = { low: 0.1, medium: 0.07, high: 0.05, ultra: 0.035 } as const; // hex radius in degrees
type Detail = keyof typeof DETAIL;

const toXZ = (lon: number, lat: number): [number, number] => [(lon - LON0) * COS * SCALE, -(lat - LAT0) * SCALE];
const toLonLat = (x: number, z: number): [number, number] => [LON0 + x / (COS * SCALE), LAT0 - z / SCALE];

function inPoly(pt: [number, number], poly: [number, number][]) {
  let inside = false;
  for (let i = 0, j = poly.length - 1; i < poly.length; j = i++) {
    const [xi, yi] = poly[i];
    const [xj, yj] = poly[j];
    if (yi > pt[1] !== yj > pt[1] && pt[0] < ((xj - xi) * (pt[1] - yi)) / (yj - yi) + xi) inside = !inside;
  }
  return inside;
}


type Region = {
  tiles: { x: number; z: number; e: number }[];
  cx: number;
  cz: number;
  radius: number;
  cityElev: number;
  extent: number;
  maxElev: number;
  meanElev: number;
};

function buildRegions(hexDeg: number): Region[] {
  const R = hexDeg * SCALE;
  const cityXZ = CITIES.map((c) => toXZ(c.lon, c.lat));
  const regions: Region[] = CITIES.map((c) => ({
    tiles: [],
    cx: 0,
    cz: 0,
    radius: R,
    cityElev: elevation(c.lon, c.lat),
    extent: 1,
    maxElev: 0,
    meanElev: 0,
  }));
  const dx = Math.sqrt(3) * R;
  const dz = 1.5 * R;
  for (let row = 0, z = -32; z < 32; row++, z += dz) {
    for (let x = -16 + (row % 2 ? dx / 2 : 0); x < 16; x += dx) {
      const ll = toLonLat(x, z);
      if (!LAND.some((p) => inPoly(ll, p))) continue;
      let best = 0;
      let bestD = Infinity;
      cityXZ.forEach(([cx, cz], i) => {
        const d = (cx - x) ** 2 + (cz - z) ** 2;
        if (d < bestD) {
          bestD = d;
          best = i;
        }
      });
      regions[best].tiles.push({ x, z, e: elevation(ll[0], ll[1]) });
    }
  }
  for (const r of regions) {
    const n = Math.max(1, r.tiles.length);
    r.cx = r.tiles.reduce((s, t) => s + t.x, 0) / n;
    r.cz = r.tiles.reduce((s, t) => s + t.z, 0) / n;
    r.extent = r.tiles.reduce((m, t) => Math.max(m, Math.hypot(t.x - r.cx, t.z - r.cz)), 0) + R;
    r.maxElev = r.tiles.reduce((m, t) => Math.max(m, t.e), 0);
    r.meanElev = r.tiles.reduce((sum, t) => sum + t.e, 0) / n;
  }
  return regions;
}

/* ------------------------------------------------------------------ */
/* Labelled slider (names the Radix thumb for assistive tech)          */
/* ------------------------------------------------------------------ */

function EffectSlider({
  label,
  value,
  display,
  min,
  max,
  step,
  onChange,
}: {
  label: string;
  value: number;
  display: string;
  min: number;
  max: number;
  step: number;
  onChange: (v: number) => void;
}) {
  const wrap = useRef<HTMLDivElement>(null);
  const id = useId();
  useEffect(() => {
    const thumb = wrap.current?.querySelector('[role="slider"]');
    if (thumb) {
      thumb.setAttribute("aria-label", label);
      thumb.setAttribute("aria-valuetext", display);
    }
  }, [label, display]);
  return (
    <div ref={wrap} className="space-y-2">
      <div className="flex items-baseline justify-between gap-2 text-sm">
        <span id={id} className="font-medium">
          {label}
        </span>
        <span className="tabular-nums text-foreground">{display}</span>
      </div>
      <Slider value={[value]} min={min} max={max} step={step} onValueChange={(v) => onChange(v[0])} aria-labelledby={id} />
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* Page                                                                */
/* ------------------------------------------------------------------ */

export function HomePage() {
  const [settings, setSettings] = useState<Settings>(DEFAULTS);
  const [active, setActive] = useState(-1);
  const [locked, setLocked] = useState(-1);

  const settingsRef = useRef(settings);
  const lockedRef = useRef(-1);
  const listHoverRef = useRef(-1);
  const layoutDirty = useRef(true);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const wrapRef = useRef<HTMLDivElement>(null);
  const labelRef = useRef<HTMLDivElement>(null);

  const [detail, setDetail] = useState<Detail>("high");
  const regions = useMemo(() => buildRegions(DETAIL[detail]), [detail]);
  const tileCount = useMemo(() => regions.reduce((n, r) => n + r.tiles.length, 0), [regions]);
  const orbitRef = useRef({ theta: 0, phi: 0.78, radius: 88 });
  const resetViewRef = useRef(false);
  const [metric, setMetric] = useState<MetricChoice>("none");
  const stats = useMemo(() => CITIES.map((c) => statsFor(c.province)), []);
  const metricDef = METRICS.find((m) => m.key === metric) ?? null;
  const breaks = useMemo(() => (metric === "none" ? [] : quantileBreaks(stats.map((s) => s[metric]))), [metric, stats]);
  const ranks = useMemo(() => {
    if (metric === "none") return [] as number[];
    const order = stats.map((s, i) => ({ v: s[metric], i })).sort((a, b) => b.v - a.v);
    const r: number[] = [];
    order.forEach((o, k) => (r[o.i] = k + 1));
    return r;
  }, [metric, stats]);
  const fillRef = useRef<(THREE.Color | null)[]>([]);
  const heightRef = useRef<number[] | null>(null);
  const sizeRef = useRef<number[] | null>(null);
  const avgRef = useRef(0);
  const avgLabelRef = useRef<HTMLDivElement>(null);
  const valueLabelRefs = useRef<(HTMLDivElement | null)[]>([]);
  const hasMetric = metric !== "none";
  const maxValue = metric === "none" ? 0 : Math.max(...stats.map((s) => s[metric]));
  const total = metric === "none" ? 0 : stats.reduce((sum, s) => sum + s[metric], 0);
  const top5 = useMemo(
    () => (metric === "none" ? [] : stats.map((s, i) => ({ v: s[metric], i })).sort((a, b) => b.v - a.v).slice(0, 5).map((o) => o.i)),
    [metric, stats],
  );
  const showLabelRef = useRef<boolean[]>([]);
  useEffect(() => {
    showLabelRef.current = CITIES.map((_, i) =>
      hasMetric && (settings.labels === "all" || (settings.labels === "top5" && top5.includes(i))),
    );
  }, [hasMetric, settings.labels, top5]);
  const average = hasMetric ? total / CITIES.length : 0;
  useEffect(() => {
    const was = heightRef.current !== null;
    if (hasMetric) {
      const vals = stats.map((s) => s[metric as MetricKey] / maxValue);
      heightRef.current = vals.map((v) => Math.max(0.15, v * settings.valueHeight));
      // bubble radius ∝ √value so bubble AREA is proportional to the value
      sizeRef.current = vals.map((v) => Math.sqrt(v) * settings.valueHeight * 0.22);
      avgRef.current = (average / maxValue) * settings.valueHeight;
    } else {
      heightRef.current = null;
      sizeRef.current = null;
    }
    if (was !== hasMetric) layoutDirty.current = true;
  }, [hasMetric, metric, maxValue, average, settings.valueHeight, stats]);
  useEffect(() => {
    fillRef.current = stats.map((s) => (metric === "none" ? null : new THREE.Color(RAMP[classOf(s[metric], breaks)])));
  }, [metric, stats, breaks]);

  useEffect(() => {
    const prev = settingsRef.current;
    if (prev.height !== settings.height || prev.gap !== settings.gap || prev.exag !== settings.exag) {
      layoutDirty.current = true;
    }
    settingsRef.current = settings;
  }, [settings]);

  const setLock = useCallback((i: number) => {
    lockedRef.current = i;
    setLocked(i);
  }, []);

  /* ---------------- three.js scene ---------------- */
  useEffect(() => {
    const canvas = canvasRef.current;
    const wrap = wrapRef.current;
    if (!canvas || !wrap) return;

    const renderer = new THREE.WebGLRenderer({ canvas, antialias: true, alpha: true });
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;

    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(38, 1, 0.1, 500);

    scene.add(new THREE.HemisphereLight(0xcfe3ff, 0x1b2333, 1.1));
    const sun = new THREE.DirectionalLight(0xffffff, 2.2);
    sun.position.set(-25, 60, 25);
    sun.castShadow = true;
    sun.shadow.mapSize.set(2048, 2048);
    Object.assign(sun.shadow.camera, { left: -40, right: 40, top: 40, bottom: -40, near: 1, far: 200 });
    scene.add(sun);

    const groundGeo = new THREE.PlaneGeometry(300, 300);
    const groundMat = new THREE.ShadowMaterial({ opacity: 0.35 });
    const ground = new THREE.Mesh(groundGeo, groundMat);
    ground.rotation.x = -Math.PI / 2;
    ground.receiveShadow = true;
    scene.add(ground);

    const hexGeo = new THREE.CylinderGeometry(1, 1, 1, 6);
    const barGeo = new THREE.CylinderGeometry(1, 1, 1, 24);
    barGeo.translate(0, 0.5, 0);
    const ballGeo = new THREE.SphereGeometry(1, 32, 20);
    const avgGeo = new THREE.PlaneGeometry(34, 66);
    const avgMat = new THREE.MeshBasicMaterial({ color: 0xf2a33a, transparent: true, opacity: 0, side: THREE.DoubleSide, depthWrite: false });
    const avgPlane = new THREE.Mesh(avgGeo, avgMat);
    avgPlane.rotation.x = -Math.PI / 2;
    avgPlane.renderOrder = 2;
    scene.add(avgPlane);
    const avgEdges = new THREE.LineSegments(new THREE.EdgesGeometry(avgGeo), new THREE.LineBasicMaterial({ color: 0xf2a33a, transparent: true, opacity: 0 }));
    avgPlane.add(avgEdges);
    let avgY = 0;
    let avgOp = 0;

    // ---- cinematic focus FX (holographic survey look) ----
    const CYAN = 0x5ee7ff;
    const additive = (opacity: number) =>
      new THREE.MeshBasicMaterial({ color: CYAN, transparent: true, opacity, blending: THREE.AdditiveBlending, depthWrite: false, side: THREE.DoubleSide });
    const fx = new THREE.Group();
    fx.visible = false;
    scene.add(fx);
    const polar = new THREE.PolarGridHelper(1, 16, 6, 96, CYAN, 0x2a8fb0);
    const polarMat = polar.material as THREE.LineBasicMaterial;
    polarMat.transparent = true;
    polarMat.blending = THREE.AdditiveBlending;
    polarMat.depthWrite = false;
    fx.add(polar);
    const ringGeo = new THREE.RingGeometry(0.97, 1, 128);
    ringGeo.rotateX(-Math.PI / 2);
    const pulseMat = additive(0.6);
    const pulse = new THREE.Mesh(ringGeo, pulseMat);
    fx.add(pulse);
    const discGeo = new THREE.CircleGeometry(1, 96);
    discGeo.rotateX(-Math.PI / 2);
    const scanMat = additive(0.1);
    const scan = new THREE.Mesh(discGeo, scanMat);
    const scanEdgeMat = additive(0.7);
    const scanEdge = new THREE.Mesh(ringGeo, scanEdgeMat);
    scan.add(scanEdge);
    fx.add(scan);
    const beamGeo = new THREE.CylinderGeometry(0.06, 0.18, 1, 16, 1, true);
    beamGeo.translate(0, 0.5, 0);
    const beamMat = additive(0.45);
    const beam = new THREE.Mesh(beamGeo, beamMat);
    scene.add(beam);
    const PCOUNT = 700;
    const pBase = new Float32Array(PCOUNT * 3);
    for (let n = 0; n < PCOUNT; n++) {
      const ang = Math.random() * Math.PI * 2;
      const rr = Math.sqrt(Math.random());
      pBase[n * 3] = Math.cos(ang) * rr;
      pBase[n * 3 + 1] = Math.random();
      pBase[n * 3 + 2] = Math.sin(ang) * rr;
    }
    const pGeo = new THREE.BufferGeometry();
    const pPos = new Float32Array(pBase);
    pGeo.setAttribute("position", new THREE.BufferAttribute(pPos, 3));
    const pMat = new THREE.PointsMaterial({ color: 0xa8f3ff, size: 0.07, transparent: true, opacity: 0.8, blending: THREE.AdditiveBlending, depthWrite: false });
    const particles = new THREE.Points(pGeo, pMat);
    scene.add(particles);
    let focusAmt = 0;
    let focusIdx = -1;
    let lastFocus = -1;
    let camT = 99;
    let thetaGoal: number | null = null;
    const camTarget = new THREE.Vector3();
    const camGoal = new THREE.Vector3();
    const overview = { radius: orbitRef.current.radius, phi: orbitRef.current.phi };
    const highlight = new THREE.Color(0xf2a33a);
    const tmpColor = new THREE.Color();
    const tmpM = new THREE.Matrix4();
    const tmpQ = new THREE.Quaternion();
    const tmpS = new THREE.Vector3();
    const tmpP = new THREE.Vector3();

    const items = regions.map((r, i) => {
      const base = new THREE.Color(1, 1, 1).multiplyScalar(0.86 + ((i * 7) % 4) * 0.045); // subtle per-area tone over terrain colours
      const mat = new THREE.MeshStandardMaterial({ color: base.clone(), roughness: 0.6, metalness: 0.05, transparent: true });
      const mesh = new THREE.InstancedMesh(hexGeo, mat, Math.max(1, r.tiles.length));
      mesh.castShadow = true;
      mesh.receiveShadow = true;
      mesh.userData.idx = i;
      const city = CITIES[i];
      const [px, pz] = toXZ(city.lon, city.lat);
      const symMat = new THREE.MeshStandardMaterial({ color: 0x93c9e4, roughness: 0.35, metalness: 0.15, transparent: true });
      const bar = new THREE.Mesh(barGeo, symMat);
      bar.position.set(px - r.cx, 0, pz - r.cz);
      bar.castShadow = true;
      bar.userData.idx = i;
      bar.visible = false;
      const ball = new THREE.Mesh(ballGeo, symMat);
      ball.position.set(px - r.cx, 0, pz - r.cz);
      ball.castShadow = true;
      ball.userData.idx = i;
      ball.visible = false;
      const group = new THREE.Group();
      group.add(mesh, bar, ball);
      group.position.set(r.cx, 0, r.cz);
      scene.add(group);
      return { r, mat, mesh, group, base, bar, ball, symMat, barH: 0, ballR: 0, cur: base.clone(), symCur: new THREE.Color(0x93c9e4), labelY: 1, cityBase: 1, ys: 1, lift: 0, s: 1, ox: 0, oz: 0, hl: 0, dim: 0, rot: 0, top: 1 };
    });

    const white = new THREE.Color(1, 1, 1);
    const applyLayout = (flat: boolean) => {
      const st = settingsRef.current;
      for (const it of items) {
        const rad = it.r.radius * (1 - st.gap);
        let top = 0;
        it.r.tiles.forEach((t, k) => {
          const h = flat ? 1 : st.height + (t.e / 1000) * st.exag;
          top = Math.max(top, h);
          tmpP.set(t.x - it.r.cx, h / 2, t.z - it.r.cz);
          tmpS.set(rad, h, rad);
          tmpM.compose(tmpP, tmpQ, tmpS);
          it.mesh.setMatrixAt(k, tmpM);
          if (flat) it.mesh.setColorAt(k, white);
          else {
            const [r, g, b] = terrainColor(t.e);
            it.mesh.setColorAt(k, tmpColor.setRGB(r, g, b));
          }
        });
        it.top = top;
        it.cityBase = flat ? 1 : st.height + (it.r.cityElev / 1000) * st.exag;
        it.mesh.instanceMatrix.needsUpdate = true;
        if (it.mesh.instanceColor) it.mesh.instanceColor.needsUpdate = true;
        it.mesh.computeBoundingSphere();
        it.mesh.computeBoundingBox();
      }
    };

    let lastFlat = !!heightRef.current && settingsRef.current.viz === "prism";
    applyLayout(lastFlat);
    for (const it of items) it.mat.needsUpdate = true;
    layoutDirty.current = false;

    // orbit camera state
    const orbit = orbitRef.current;
    const pointer = { x: 9, y: 9, inside: false, down: false, sx: 0, sy: 0, lx: 0, ly: 0, moved: 0 };
    let sceneHover = -1;
    let lastActive = -2;

    const onDown = (e: PointerEvent) => {
      pointer.down = true;
      pointer.sx = pointer.lx = e.clientX;
      pointer.sy = pointer.ly = e.clientY;
      pointer.moved = 0;
      wrap.setPointerCapture(e.pointerId);
    };
    const onMove = (e: PointerEvent) => {
      const rect = wrap.getBoundingClientRect();
      pointer.x = ((e.clientX - rect.left) / rect.width) * 2 - 1;
      pointer.y = -((e.clientY - rect.top) / rect.height) * 2 + 1;
      pointer.inside = true;
      if (pointer.down) {
        const dx = e.clientX - pointer.lx;
        const dy = e.clientY - pointer.ly;
        pointer.moved += Math.abs(dx) + Math.abs(dy);
        orbit.theta -= dx * 0.006;
        orbit.phi = Math.min(1.35, Math.max(0.12, orbit.phi - dy * 0.005));
        pointer.lx = e.clientX;
        pointer.ly = e.clientY;
      }
    };
    const onUp = (e: PointerEvent) => {
      if (pointer.down && pointer.moved < 6 && (settingsRef.current.lockOnClick || settingsRef.current.cinematic)) {
        // Raycast at the release point: hover tracking is paused while the button is held.
        const rect = wrap.getBoundingClientRect();
        ndc.set(((e.clientX - rect.left) / rect.width) * 2 - 1, -((e.clientY - rect.top) / rect.height) * 2 + 1);
        raycaster.setFromCamera(ndc, camera);
        const hit = raycaster.intersectObjects(meshes.filter((m) => m.visible), false)[0];
        const picked = hit ? (hit.object.userData.idx as number) : -1;
        const next = picked >= 0 && picked !== lockedRef.current ? picked : -1;
        lockedRef.current = next;
        setLocked(next);
      }
      pointer.down = false;
      if (wrap.hasPointerCapture(e.pointerId)) wrap.releasePointerCapture(e.pointerId);
    };
    const onLeave = () => {
      pointer.inside = false;
    };
    const onWheel = (e: WheelEvent) => {
      e.preventDefault();
      orbit.radius = Math.min(150, Math.max(4, orbit.radius * Math.exp(e.deltaY * 0.001)));
      camT = 99;
    };
    wrap.addEventListener("pointerdown", onDown);
    wrap.addEventListener("pointermove", onMove);
    wrap.addEventListener("pointerup", onUp);
    wrap.addEventListener("pointerleave", onLeave);
    wrap.addEventListener("wheel", onWheel, { passive: false });

    const resize = () => {
      const w = wrap.clientWidth;
      const h = wrap.clientHeight;
      renderer.setSize(w, h, false);
      camera.aspect = w / Math.max(1, h);
      camera.updateProjectionMatrix();
    };
    const ro = new ResizeObserver(resize);
    ro.observe(wrap);
    resize();

    const raycaster = new THREE.Raycaster();
    const ndc = new THREE.Vector2();
    const meshes = items.flatMap((it) => [it.mesh, it.bar, it.ball]);
    const clock = new THREE.Clock();
    const labelPos = new THREE.Vector3();
    let raf = 0;

    const tick = () => {
      raf = requestAnimationFrame(tick);
      const dt = Math.min(clock.getDelta(), 0.05);
      const t = clock.elapsedTime;
      const st = settingsRef.current;
      const flatNow = !!heightRef.current && st.viz === "prism";
      if (layoutDirty.current || flatNow !== lastFlat) {
        layoutDirty.current = false;
        lastFlat = flatNow;
        applyLayout(flatNow);
      }

      if (resetViewRef.current) {
        resetViewRef.current = false;
        lockedRef.current = -1;
        overview.radius = 88;
        overview.phi = 0.78;
        // unwrap so the camera turns the short way back to north-up
        orbit.theta = Math.atan2(Math.sin(orbit.theta), Math.cos(orbit.theta));
        thetaGoal = 0;
        lastFocus = -1;
        camT = 0;
      }

      // cinematic focus: fly the camera to the locked city
      const want = st.cinematic && lockedRef.current >= 0 ? lockedRef.current : -1;
      if (want !== lastFocus) {
        if (lastFocus < 0 && want >= 0) {
          overview.radius = orbit.radius;
          overview.phi = orbit.phi;
        }
        lastFocus = want;
        camT = 0;
      }
      if (want >= 0) focusIdx = want;
      camT += dt;
      focusAmt += ((want >= 0 ? 1 : 0) - focusAmt) * (1 - Math.exp(-2.4 * dt));
      const kc = 1 - Math.exp(-2.6 * dt);
      const fIt = want >= 0 ? items[want] : null;
      if (fIt) {
        const ext = fIt.r.extent * fIt.s;
        const fit = (ext * 0.8) / Math.tan(((camera.fov / 2) * Math.PI) / 180) / Math.min(1, camera.aspect);
        camGoal.set(fIt.group.position.x, fIt.lift + fIt.top * fIt.ys * fIt.s * 0.35, fIt.group.position.z);
        if (camT < 3) {
          orbit.radius += (Math.max(6, fit) - orbit.radius) * kc;
          orbit.phi += (1.02 - orbit.phi) * kc;
        }
        if (!pointer.down) orbit.theta += dt * 0.05;
      } else {
        camGoal.set(0, 0, 0);
        if (camT < 3) {
          orbit.radius += (overview.radius - orbit.radius) * kc;
          orbit.phi += (overview.phi - orbit.phi) * kc;
          if (thetaGoal !== null) orbit.theta += (thetaGoal - orbit.theta) * kc;
        } else {
          thetaGoal = null;
        }
      }
      camTarget.lerp(camGoal, kc);

      if (st.autoRotate && !pointer.down && !fIt) orbit.theta += dt * 0.12;
      const sp = Math.sin(orbit.phi);
      camera.position.set(
        camTarget.x + orbit.radius * sp * Math.sin(orbit.theta),
        camTarget.y + orbit.radius * Math.cos(orbit.phi),
        camTarget.z + orbit.radius * sp * Math.cos(orbit.theta),
      );
      camera.lookAt(camTarget);
      camera.updateMatrixWorld();

      sceneHover = -1;
      if (pointer.inside && !pointer.down) {
        ndc.set(pointer.x, pointer.y);
        raycaster.setFromCamera(ndc, camera);
        const hit = raycaster.intersectObjects(meshes.filter((m) => m.visible), false)[0];
        if (hit) sceneHover = hit.object.userData.idx as number;
      }
      wrap.style.cursor = pointer.down ? "grabbing" : sceneHover >= 0 ? "pointer" : "grab";

      const act = lockedRef.current >= 0 ? lockedRef.current : sceneHover >= 0 ? sceneHover : listHoverRef.current;
      if (act !== lastActive) {
        lastActive = act;
        setActive(act);
      }

      const k = 1 - Math.exp(-st.speed * dt);
      const a = act >= 0 ? items[act] : null;
      for (let i = 0; i < items.length; i++) {
        const it = items[i];
        const on = i === act;
        let tox = 0;
        let toz = 0;
        if (a && !on) {
          const dx = it.r.cx - a.r.cx;
          const dz = it.r.cz - a.r.cz;
          const d = Math.hypot(dx, dz) || 1;
          const f = (st.push * 8) / (d + 6);
          tox = (dx / d) * f;
          toz = (dz / d) * f;
        }
        const focusedThis = fIt === it;
        it.lift += ((on ? st.lift + (focusedThis ? 1.5 : 0) : -6 * focusAmt) - it.lift) * k;
        it.s += ((on ? st.pop : 1) - it.s) * k;
        it.ox += (tox - it.ox) * k;
        it.oz += (toz - it.oz) * k;
        it.hl += ((on ? (focusedThis ? 1 - 0.7 * focusAmt : 1) : 0) - it.hl) * k;
        it.dim += ((a && !on ? Math.max(st.fade, 0.94 * focusAmt) : 0) - it.dim) * k;
        it.rot += ((on ? Math.sin(t * 3) * st.wobble * 0.18 : 0) - it.rot) * Math.min(1, k * 2);

        it.group.position.set(it.r.cx + it.ox, it.lift, it.r.cz + it.oz);
        it.group.scale.setScalar(it.s);
        const H = heightRef.current;
        const R = sizeRef.current;
        const mode = st.viz;
        const ysT = (H && mode === "prism" ? H[i] : 1) * (focusedThis && !flatNow ? 1 + 1.6 * focusAmt : 1);
        const barT = H && mode === "bars" ? H[i] : 0;
        const ballT = R && mode === "bubbles" ? R[i] : 0;
        it.ys += (ysT - it.ys) * k;
        it.barH += (barT - it.barH) * k;
        it.ballR += (ballT - it.ballR) * k;
        it.mesh.scale.y = it.ys;
        it.bar.visible = it.barH > 0.02;
        it.bar.position.y = it.cityBase * it.ys;
        it.bar.scale.set(0.55, it.barH, 0.55);
        it.ball.visible = it.ballR > 0.02;
        it.ball.position.y = it.cityBase * it.ys + it.ballR + 0.15;
        it.ball.scale.setScalar(Math.max(0.001, it.ballR));
        it.labelY = mode === "bars" && H ? it.cityBase * it.ys + it.barH : mode === "bubbles" && R ? it.cityBase * it.ys + it.ballR * 2 + 0.15 : it.top * it.ys;
        it.group.rotation.set(it.rot * 0.4, it.rot, it.rot * 0.3);
        const fill = fillRef.current[i];
        it.cur.lerp(fill && flatNow ? fill : it.base, k);
        if (fill) it.symCur.lerp(fill, k);
        it.symMat.color.copy(it.symCur).lerp(highlight, it.hl);
        it.symMat.emissive.copy(highlight).multiplyScalar(it.hl * 0.25);
        it.symMat.opacity = 1 - it.dim;
        it.symMat.depthWrite = it.symMat.opacity > 0.98;
        tmpColor.copy(it.cur).lerp(highlight, it.hl);
        it.mat.color.copy(tmpColor);
        it.mat.emissive.copy(highlight).multiplyScalar(it.hl * 0.18);
        it.mat.opacity = 1 - it.dim;
        it.mat.depthWrite = it.mat.opacity > 0.98;
      }

      const label = labelRef.current;
      if (label) {
        if (a) {
          labelPos.set(a.group.position.x, a.lift + a.labelY * a.s + 1.2, a.group.position.z).project(camera);
          const x = (labelPos.x * 0.5 + 0.5) * wrap.clientWidth;
          const y = (-labelPos.y * 0.5 + 0.5) * wrap.clientHeight;
          label.style.transform = `translate(${x}px, ${y}px) translate(-50%, -100%)`;
          label.style.opacity = String(Math.min(1, a.hl * 1.4) * (1 - focusAmt));
        } else {
          label.style.opacity = "0";
        }
      }

      // persistent value labels
      for (let n = 0; n < items.length; n++) {
        const el = valueLabelRefs.current[n];
        if (!el) continue;
        if (!showLabelRef.current[n] || n === act) {
          el.style.opacity = "0";
          continue;
        }
        const it = items[n];
        const sym = st.viz === "prism" ? it.group.position : tmpP.copy(it.bar.position).multiplyScalar(it.s).add(it.group.position);
        labelPos.set(sym.x, it.lift + it.labelY * it.s + 0.5, sym.z).project(camera);
        el.style.transform = `translate(${(labelPos.x * 0.5 + 0.5) * wrap.clientWidth}px, ${(-labelPos.y * 0.5 + 0.5) * wrap.clientHeight}px) translate(-50%, -100%)`;
        el.style.opacity = String((1 - it.dim) * (1 - focusAmt));
      }

      // holographic FX around the focused city
      const fxIt = focusIdx >= 0 ? items[focusIdx] : null;
      fx.visible = beam.visible = particles.visible = focusAmt > 0.01 && !!fxIt;
      if (fxIt && fx.visible) {
        const ext = fxIt.r.extent * fxIt.s;
        const topY = fxIt.top * fxIt.ys * fxIt.s;
        fx.position.set(fxIt.group.position.x, fxIt.lift - 0.05, fxIt.group.position.z);
        polar.scale.setScalar(ext * 1.45);
        polar.rotation.y = t * 0.08;
        polarMat.opacity = 0.55 * focusAmt;
        const ph = (t * 0.45) % 1;
        pulse.scale.setScalar(ext * (0.2 + ph * 1.5));
        pulseMat.opacity = (1 - ph) * 0.8 * focusAmt;
        scan.position.y = 0.1 + (0.5 + 0.5 * Math.sin(t * 1.3)) * topY;
        scan.scale.setScalar(ext * 1.02);
        scanMat.opacity = 0.08 * focusAmt;
        scanEdgeMat.opacity = 0.75 * focusAmt;
        tmpP.copy(fxIt.bar.position).multiplyScalar(fxIt.s).add(fxIt.group.position);
        beam.position.set(tmpP.x, fxIt.lift + fxIt.cityBase * fxIt.ys * fxIt.s, tmpP.z);
        beam.scale.set(1, 18 + Math.sin(t * 2) * 0.5, 1);
        beamMat.opacity = (0.35 + 0.15 * Math.sin(t * 6)) * focusAmt;
        particles.position.set(fxIt.group.position.x, fxIt.lift, fxIt.group.position.z);
        particles.scale.set(ext * 1.3, topY + 6, ext * 1.3);
        for (let n = 0; n < PCOUNT; n++) pPos[n * 3 + 1] = (pBase[n * 3 + 1] + t * 0.04 * (0.5 + (n % 5) * 0.2)) % 1;
        pGeo.attributes.position.needsUpdate = true;
        pMat.opacity = 0.85 * focusAmt;
      }

      // national-average reference plane
      const showAvg = st.showAverage && flatNow;
      const avgTarget = avgRef.current;
      avgY += (avgTarget - avgY) * k;
      avgOp += ((showAvg ? 1 : 0) - avgOp) * k;
      avgPlane.position.y = avgY;
      avgPlane.visible = avgOp > 0.01;
      avgMat.opacity = avgOp * 0.14;
      (avgEdges.material as THREE.LineBasicMaterial).opacity = avgOp * 0.8;
      const al = avgLabelRef.current;
      if (al) {
        labelPos.set(17, avgY, -10).project(camera);
        al.style.transform = `translate(${(labelPos.x * 0.5 + 0.5) * wrap.clientWidth}px, ${(-labelPos.y * 0.5 + 0.5) * wrap.clientHeight}px) translate(-100%, -50%)`;
        al.style.opacity = String(avgOp);
      }

      renderer.render(scene, camera);
    };
    tick();

    return () => {
      cancelAnimationFrame(raf);
      ro.disconnect();
      wrap.removeEventListener("pointerdown", onDown);
      wrap.removeEventListener("pointermove", onMove);
      wrap.removeEventListener("pointerup", onUp);
      wrap.removeEventListener("pointerleave", onLeave);
      wrap.removeEventListener("wheel", onWheel);
      for (const it of items) {
        it.mat.dispose();
        it.mesh.dispose();
      }
      for (const it of items) it.symMat.dispose();
      hexGeo.dispose();
      polar.geometry.dispose();
      polarMat.dispose();
      ringGeo.dispose();
      discGeo.dispose();
      beamGeo.dispose();
      pGeo.dispose();
      [pulseMat, scanMat, scanEdgeMat, beamMat, pMat].forEach((m) => m.dispose());
      barGeo.dispose();
      ballGeo.dispose();
      avgGeo.dispose();
      avgMat.dispose();
      avgEdges.geometry.dispose();
      (avgEdges.material as THREE.Material).dispose();
      groundGeo.dispose();
      groundMat.dispose();
      renderer.dispose();
    };
  }, [regions]);

  const set = <K extends keyof Settings>(key: K, v: Settings[K]) => setSettings((s) => ({ ...s, [key]: v }));
  const activeCity = active >= 0 ? CITIES[active] : null;
  const activeStats = active >= 0 ? stats[active] : null;
  const focused = settings.cinematic && locked >= 0;
  const focusCity = locked >= 0 ? CITIES[locked] : null;
  const focusRegion = locked >= 0 ? regions[locked] : null;
  const focusStats = locked >= 0 ? stats[locked] : null;
  const sortedCities = useMemo(
    () =>
      CITIES.map((c, i) => ({ c, i })).sort((x, y) =>
        metric === "none" ? x.c.name.localeCompare(y.c.name, "vi") : stats[y.i][metric] - stats[x.i][metric],
      ),
    [metric, stats],
  );
  const legend =
    metricDef && breaks.length
      ? RAMP.map((color, k) => {
          const lo = k === 0 ? Math.min(...stats.map((s) => s[metricDef.key])) : breaks[k - 1];
          const hi = k === RAMP.length - 1 ? Math.max(...stats.map((s) => s[metricDef.key])) : breaks[k];
          return { color, text: `${metricDef.fmt(lo)} – ${metricDef.fmt(hi)}` };
        })
      : [];

  return (
    <div className="grid h-[calc(100dvh-3.5rem)] grid-cols-1 lg:grid-cols-[minmax(0,1fr)_340px]">
      {/* Map stage */}
      <section aria-label="3D map" className="relative min-h-[420px] overflow-hidden bg-[radial-gradient(ellipse_at_center,#1a2740_0%,#0b1220_70%)]">
        <div
          ref={wrapRef}
          role="img"
          aria-label={`3D hex-tile map of Vietnam split into ${CITIES.length} city areas${activeCity ? `. ${activeCity.name} is raised.` : ""}`}
          className="absolute inset-0 touch-none select-none"
        >
          <canvas ref={canvasRef} data-aether-canvas-purpose="non-drawing" className="block h-full w-full" />
        </div>
        <div
          ref={labelRef}
          aria-hidden="true"
          className="pointer-events-none absolute left-0 top-0 rounded-md border border-amber-400/70 bg-slate-950/85 px-2.5 py-1 text-sm font-semibold text-white opacity-0 shadow-lg"
        >
          {activeCity?.name}
          {metricDef && activeStats && (
            <span className="ml-2 font-normal text-amber-200">{metricDef.fmt(activeStats[metricDef.key])}</span>
          )}
        </div>

        {/* Value labels on the map */}
        {metricDef &&
          CITIES.map((c, idx) => (
            <div
              key={c.name}
              ref={(el) => {
                valueLabelRefs.current[idx] = el;
              }}
              aria-hidden="true"
              className="pointer-events-none absolute left-0 top-0 whitespace-nowrap rounded bg-slate-950/80 px-1.5 py-0.5 text-[11px] leading-tight text-white opacity-0"
            >
              <span className="font-semibold">
                {settings.labels === "top5" && `#${ranks[idx]} `}
                {c.name}
              </span>{" "}
              <span className="text-sky-200">{metricDef.fmt(stats[idx][metricDef.key])}</span>
            </div>
          ))}
        <div
          ref={avgLabelRef}
          aria-hidden="true"
          className="pointer-events-none absolute left-0 top-0 whitespace-nowrap rounded border border-amber-400/70 bg-slate-950/85 px-2 py-0.5 text-xs text-amber-100 opacity-0"
        >
          National average {metricDef ? metricDef.fmt(average) : ""}
        </div>

        {/* On-map visualisation controls */}
        <div
          inert={focused}
          className={`absolute right-4 top-4 w-[24rem] max-w-[calc(100%-2rem)] space-y-3 rounded-lg border border-border bg-card/95 p-3 text-card-foreground shadow-xl backdrop-blur-sm transition-opacity duration-500 ${focused ? "pointer-events-none opacity-0" : ""}`}
        >
          <div className="space-y-1.5">
            <div id="metric-h" className="text-xs font-semibold uppercase tracking-wide">
              Indicator
            </div>
            <ToggleGroup
              type="single"
              variant="outline"
              size="sm"
              spacing={1}
              value={metric}
              onValueChange={(v) => v && setMetric(v as MetricChoice)}
              aria-labelledby="metric-h"
              className="flex w-full flex-wrap justify-start"
            >
              <ToggleGroupItem value="none">None</ToggleGroupItem>
              {METRICS.map((m) => (
                <ToggleGroupItem key={m.key} value={m.key}>
                  {m.short}
                </ToggleGroupItem>
              ))}
            </ToggleGroup>
          </div>
          {metricDef && (
            <>
              <div className="space-y-1.5">
                <div id="viz-h" className="text-xs font-semibold uppercase tracking-wide">
                  Show as
                </div>
                <ToggleGroup
                  type="single"
                  variant="outline"
                  size="sm"
                  spacing={1}
                  value={settings.viz}
                  onValueChange={(v) => v && set("viz", v as Viz)}
                  aria-labelledby="viz-h"
                  className="flex w-full flex-wrap justify-start"
                >
                  {VIZ_OPTIONS.map((o) => (
                    <ToggleGroupItem key={o.value} value={o.value}>
                      {o.label}
                    </ToggleGroupItem>
                  ))}
                </ToggleGroup>
              </div>
              <div className="flex flex-wrap items-end gap-x-5 gap-y-3">
                <div className="space-y-1.5">
                  <div id="labels-h" className="text-xs font-semibold uppercase tracking-wide">
                    Labels
                  </div>
                  <ToggleGroup
                    type="single"
                    variant="outline"
                    size="sm"
                    spacing={1}
                    value={settings.labels}
                    onValueChange={(v) => v && set("labels", v as LabelMode)}
                    aria-labelledby="labels-h"
                  >
                    <ToggleGroupItem value="none">Off</ToggleGroupItem>
                    <ToggleGroupItem value="top5">Top 5</ToggleGroupItem>
                    <ToggleGroupItem value="all">All</ToggleGroupItem>
                  </ToggleGroup>
                </div>
                {settings.viz === "prism" && (
                  <div className="flex items-center gap-2 pb-1.5">
                    <Switch id="sw-avg" checked={settings.showAverage} onCheckedChange={(v) => set("showAverage", v)} />
                    <Label htmlFor="sw-avg">Average plane</Label>
                  </div>
                )}
              </div>
              <EffectSlider
                label={settings.viz === "bubbles" ? "Max bubble size" : "Max height"}
                value={settings.valueHeight}
                display={settings.valueHeight.toFixed(0)}
                min={2}
                max={25}
                step={1}
                onChange={(v) => set("valueHeight", v)}
              />
            </>
          )}
        </div>

        {/* City details */}
        <div
          className={`pointer-events-none absolute left-4 top-4 w-72 rounded-lg bg-slate-950/80 px-4 py-3 text-white shadow-xl backdrop-blur-sm transition-opacity duration-500 ${focused ? "pointer-events-none opacity-0" : ""}`}
          aria-live="polite"
        >
          <div className="text-xs uppercase tracking-wide text-slate-300">{locked >= 0 ? "Locked" : "City"}</div>
          <div className="text-xl font-semibold">{activeCity ? activeCity.name : "—"}</div>
          {activeCity && activeStats && (
            <>
              <div className="text-sm text-slate-300">{activeCity.province} province</div>
              <dl className="mt-3 grid grid-cols-[auto_1fr] gap-x-4 gap-y-1.5 text-sm">
                {[
                  ["Population", `${activeStats.pop.toFixed(2)} million`],
                  ["Area", `${activeStats.area.toLocaleString("en-US")} km²`],
                  ["Density", `${Math.round(activeStats.density).toLocaleString("en-US")} people/km²`],
                  ["GRDP", `${activeStats.grdp.toLocaleString("en-US")} trillion ₫`],
                  ["GRDP per capita", `${Math.round(activeStats.perCapita).toLocaleString("en-US")} million ₫`],
                  ["GRDP growth", `${activeStats.growth.toFixed(1)}%`],
                ].map(([k, v]) => (
                  <div key={k} className="contents">
                    <dt className="text-slate-300">{k}</dt>
                    <dd className="m-0 text-right font-medium tabular-nums">{v}</dd>
                  </div>
                ))}
              </dl>
              {metricDef && ranks[active] && (
                <div className="mt-3 space-y-0.5 border-t border-white/15 pt-2 text-sm">
                  {(metricDef.key === "pop" || metricDef.key === "grdp") && (
                    <div>
                      <span className="text-slate-300">Share of national {metricDef.label.toLowerCase()} </span>
                      <span className="font-semibold text-amber-200">{((activeStats[metricDef.key] / total) * 100).toFixed(1)}%</span>
                    </div>
                  )}
                  <div>
                    <span className="text-slate-300">{metricDef.label} rank </span>
                    <span className="font-semibold text-amber-200">
                      #{ranks[active]} of {CITIES.length}
                    </span>
                  </div>
                </div>
              )}
            </>
          )}
        </div>

        {/* Legend */}
        {(!metricDef || settings.viz !== "prism") && (
          <div className={`pointer-events-none absolute left-4 rounded-lg bg-slate-950/80 px-4 py-3 text-white backdrop-blur-sm ${metricDef ? "bottom-48" : "bottom-4"} transition-opacity duration-500 ${focused ? "pointer-events-none opacity-0" : ""}`}>
            <div className="mb-2 text-sm font-semibold">Elevation</div>
            <ul className="space-y-1 text-xs">
              {TERRAIN_LEGEND.map((l) => (
                <li key={l.label} className="flex items-center gap-2">
                  <span
                    className="inline-block size-3.5 rounded-sm border border-white/30"
                    style={{ background: `rgb(${l.rgb.map((c) => Math.round(c * 255)).join(",")})` }}
                    aria-hidden="true"
                  />
                  <span className="tabular-nums">{l.label}</span>
                </li>
              ))}
            </ul>
          </div>
        )}
        {metricDef && (
          <div className={`pointer-events-none absolute bottom-4 left-4 rounded-lg bg-slate-950/80 px-4 py-3 text-white backdrop-blur-sm transition-opacity duration-500 ${focused ? "pointer-events-none opacity-0" : ""}`}>
            <div className="mb-2 text-sm font-semibold">{metricDef.label}</div>
            <ul className="space-y-1 text-xs">
              {legend.map((l) => (
                <li key={l.color} className="flex items-center gap-2">
                  <span className="inline-block size-3.5 rounded-sm border border-white/30" style={{ background: l.color }} aria-hidden="true" />
                  <span className="tabular-nums">{l.text}</span>
                </li>
              ))}
            </ul>
          </div>
        )}
        {/* Cinematic focus HUD */}
        {focused && focusCity && focusRegion && focusStats && (
          <div className="pointer-events-none absolute inset-0 font-mono text-cyan-200" aria-live="polite">
            <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,transparent_45%,rgba(2,6,23,0.75)_100%)]" aria-hidden="true" />
            {["left-6 top-6 border-l-2 border-t-2", "right-6 top-6 border-r-2 border-t-2", "bottom-6 left-6 border-b-2 border-l-2", "bottom-6 right-6 border-b-2 border-r-2"].map((c) => (
              <span key={c} className={`absolute size-12 border-cyan-300/80 ${c}`} aria-hidden="true" />
            ))}
            <div className="absolute left-1/2 top-8 -translate-x-1/2 text-center">
              <div className="flex items-center justify-center gap-2 text-[11px] uppercase tracking-[0.35em] text-cyan-300">
                <span className="inline-block size-1.5 animate-pulse rounded-full bg-cyan-300" aria-hidden="true" />
                Target locked
              </div>
              <h2 className="mt-1 font-sans text-4xl font-light tracking-wide text-white drop-shadow-[0_0_12px_rgba(94,231,255,0.6)]">
                {focusCity.name}
              </h2>
              <div className="mt-1 text-xs tracking-widest text-cyan-200">
                {focusCity.lat.toFixed(2)}°N · {focusCity.lon.toFixed(2)}°E · {focusCity.province.toUpperCase()}
              </div>
            </div>
            <dl className="absolute bottom-24 left-8 w-64 space-y-1.5 border-l border-cyan-300/60 bg-slate-950/55 py-3 pl-4 pr-3 text-xs backdrop-blur-sm">
              {[
                ["PEAK ELEV", `${Math.round(focusRegion.maxElev).toLocaleString("en-US")} m`],
                ["MEAN ELEV", `${Math.round(focusRegion.meanElev).toLocaleString("en-US")} m`],
                ["CITY ELEV", `${Math.round(focusRegion.cityElev).toLocaleString("en-US")} m`],
                ["SURVEY TILES", focusRegion.tiles.length.toLocaleString("en-US")],
              ].map(([k, v]) => (
                <div key={k} className="flex justify-between gap-3">
                  <dt className="tracking-widest text-cyan-300">{k}</dt>
                  <dd className="m-0 tabular-nums text-white">{v}</dd>
                </div>
              ))}
            </dl>
            <dl className="absolute bottom-24 right-8 w-72 space-y-1.5 border-r border-cyan-300/60 bg-slate-950/55 py-3 pl-3 pr-4 text-xs backdrop-blur-sm">
              {[
                ["POPULATION", `${focusStats.pop.toFixed(2)} M`],
                ["AREA", `${focusStats.area.toLocaleString("en-US")} km²`],
                ["DENSITY", `${Math.round(focusStats.density).toLocaleString("en-US")} /km²`],
                ["GRDP", `${focusStats.grdp.toLocaleString("en-US")} tn ₫`],
                ["GRDP / CAPITA", `${Math.round(focusStats.perCapita).toLocaleString("en-US")} M ₫`],
                ["GROWTH", `${focusStats.growth.toFixed(1)}%`],
              ].map(([k, v]) => (
                <div key={k} className="flex justify-between gap-3">
                  <dt className="tracking-widest text-cyan-300">{k}</dt>
                  <dd className="m-0 tabular-nums text-white">{v}</dd>
                </div>
              ))}
            </dl>
            <div className="pointer-events-auto absolute bottom-8 left-1/2 -translate-x-1/2">
              <Button
                variant="outline"
                onClick={() => setLock(-1)}
                className="border-cyan-300/70 bg-slate-950/70 font-mono tracking-widest text-cyan-100 hover:bg-cyan-950 hover:text-white"
              >
                <ArrowLeft aria-hidden="true" />
                BACK TO VIETNAM
              </Button>
            </div>
          </div>
        )}
      </section>

      {/* Controls */}
      <aside className="flex min-h-0 flex-col border-t border-border bg-card lg:border-l lg:border-t-0">
        <div className="min-h-0 flex-1 overflow-y-auto">
          <section aria-labelledby="fx-h" className="space-y-5 p-5">
            <div className="flex items-center justify-between">
              <h2 id="fx-h" className="text-base font-semibold">
                Effects
              </h2>
              <Button variant="ghost" size="sm" onClick={() => {
                  setSettings(DEFAULTS);
                  setLocked(-1);
                  listHoverRef.current = -1;
                  resetViewRef.current = true;
                }}
              >
                <RotateCcw aria-hidden="true" />
                Reset
              </Button>
            </div>
            <div className="space-y-2">
              <div className="flex items-baseline justify-between gap-2 text-sm">
                <span id="detail-h" className="font-medium">
                  Tile detail
                </span>
                <span className="tabular-nums text-foreground">{tileCount.toLocaleString("en-US")} tiles</span>
              </div>
              <ToggleGroup
                type="single"
                variant="outline"
                size="sm"
                spacing={1}
                value={detail}
                onValueChange={(v) => v && setDetail(v as Detail)}
                aria-labelledby="detail-h"
                className="flex w-full flex-wrap justify-start"
              >
                <ToggleGroupItem value="low">Low</ToggleGroupItem>
                <ToggleGroupItem value="medium">Medium</ToggleGroupItem>
                <ToggleGroupItem value="high">High</ToggleGroupItem>
                <ToggleGroupItem value="ultra">Ultra</ToggleGroupItem>
              </ToggleGroup>
            </div>
            {SLIDERS.map((s) => (
              <EffectSlider
                key={s.key}
                label={s.label}
                value={settings[s.key]}
                display={s.fmt(settings[s.key])}
                min={s.min}
                max={s.max}
                step={s.step}
                onChange={(v) => set(s.key, v)}
              />
            ))}
            <div className="flex items-center justify-between gap-3">
              <Label htmlFor="sw-rotate">Auto-rotate</Label>
              <Switch id="sw-rotate" checked={settings.autoRotate} onCheckedChange={(v) => set("autoRotate", v)} />
            </div>
            <div className="flex items-center justify-between gap-3">
              <Label htmlFor="sw-lock">Click to lock a city</Label>
              <Switch id="sw-lock" checked={settings.lockOnClick} onCheckedChange={(v) => set("lockOnClick", v)} />
            </div>
            <div className="flex items-center justify-between gap-3">
              <Label htmlFor="sw-cine">Cinematic fly-in</Label>
              <Switch id="sw-cine" checked={settings.cinematic} onCheckedChange={(v) => set("cinematic", v)} />
            </div>
          </section>

          <section aria-labelledby="cities-h" className="border-t border-border p-5">
            <div className="mb-3 flex items-center justify-between">
              <h2 id="cities-h" className="text-base font-semibold">
                Cities <span className="font-normal text-foreground">({CITIES.length})</span>
                {metricDef && (
                  <span className="block text-sm font-normal text-foreground">
                    Ranked by {metricDef.label.toLowerCase()}
                    {(metricDef.key === "pop" || metricDef.key === "grdp") &&
                      ` · top 5 = ${((top5.reduce((sum, i) => sum + stats[i][metricDef.key], 0) / total) * 100).toFixed(0)}% of total`}
                  </span>
                )}
              </h2>
              {locked >= 0 && (
                <Button variant="outline" size="sm" onClick={() => setLock(-1)}>
                  <LockOpen aria-hidden="true" />
                  Unlock
                </Button>
              )}
            </div>
            <ul className="grid grid-cols-1 gap-1">
              {sortedCities.map(({ c, i }) => (
                <li key={c.name}>
                  <button
                    type="button"
                    aria-pressed={locked === i}
                    onMouseEnter={() => (listHoverRef.current = i)}
                    onMouseLeave={() => (listHoverRef.current = -1)}
                    onFocus={() => (listHoverRef.current = i)}
                    onBlur={() => (listHoverRef.current = -1)}
                    onClick={() => setLock(locked === i ? -1 : i)}
                    className={`block w-full rounded-md px-3 py-2 text-left text-sm transition-colors hover:bg-muted focus-visible:outline-2 focus-visible:outline-ring ${
                      active === i ? "bg-muted font-semibold" : ""
                    }`}
                  >
                    <span className="flex items-center justify-between gap-2">
                    <span className="min-w-0 truncate">
                      {c.name}
                      {c.province !== c.name && <span className="font-normal text-foreground/80"> · {c.province}</span>}
                    </span>
                    <span className="flex shrink-0 items-center gap-2 tabular-nums text-foreground/80">
                      {metricDef ? metricDef.fmt(stats[i][metricDef.key]) : `${stats[i].pop.toFixed(1)} M`}
                      {locked === i && <Lock className="size-3.5 text-primary" aria-label="Locked" />}
                    </span>
                    </span>
                    {metricDef && (
                      <span className="mt-1 block h-1.5 w-full overflow-hidden rounded-full bg-muted" aria-hidden="true">
                        <span
                          className="block h-full rounded-full bg-primary"
                          style={{ width: `${(stats[i][metricDef.key] / maxValue) * 100}%` }}
                        />
                      </span>
                    )}
                  </button>
                </li>
              ))}
            </ul>
          </section>
        </div>
      </aside>
    </div>
  );
}
