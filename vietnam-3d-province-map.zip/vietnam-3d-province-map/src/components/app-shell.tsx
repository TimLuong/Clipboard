import { Outlet, useLocation } from "react-router-dom";
import { motion } from "motion/react";
import { Map as MapIcon } from "lucide-react";
import { Toaster } from "@/components/ui/sonner";

export function AppShell() {
  const { pathname } = useLocation();
  return (
    <div className="flex min-h-screen flex-col">
      <a
        href="#main"
        className="sr-only focus:not-sr-only focus:absolute focus:left-2 focus:top-2 focus:z-50 focus:rounded-md focus:bg-background focus:px-3 focus:py-2 focus:text-sm"
      >
        Skip to map
      </a>
      <header className="flex h-14 shrink-0 items-center gap-2.5 border-b border-border bg-background px-4">
        <span className="flex size-8 items-center justify-center rounded-md bg-primary text-primary-foreground">
          <MapIcon className="size-4" aria-hidden="true" />
        </span>
        <span className="font-semibold">Vietnam 3D Province Map</span>
      </header>
      <main id="main" tabIndex={-1} className="flex flex-1 flex-col outline-none">
        <motion.div
          key={pathname}
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.15, ease: "easeOut" }}
          className="flex-1"
        >
          <Outlet />
        </motion.div>
      </main>
      <Toaster />
    </div>
  );
}

export default AppShell;
