// Simplified Vietnam outline (lon, lat), traced clockwise from the north-west.
// Approximate – good enough for a stylised hex-tile map, not for measurement.
export const MAINLAND: [number, number][] = [
  [102.14, 22.4], [102.48, 22.77], [103.03, 22.44], [103.52, 22.7], [103.96, 22.5],
  [104.37, 22.7], [104.8, 22.85], [105.33, 23.35], [105.87, 22.93], [106.26, 22.98],
  [106.71, 22.86], [106.7, 22.58], [106.55, 22.22], [106.8, 21.97], [107.36, 21.6],
  [108.05, 21.55], [107.4, 21.25], [106.8, 20.85], [106.55, 20.35], [106.0, 19.95],
  [105.8, 19.4], [105.75, 18.95], [106.1, 18.4], [106.5, 17.85], [106.9, 17.2],
  [107.4, 16.75], [108.0, 16.35], [108.25, 16.05], [108.7, 15.5], [108.95, 14.9],
  [109.1, 14.3], [109.25, 13.7], [109.3, 13.0], [109.45, 12.5], [109.2, 12.0],
  [109.2, 11.6], [108.95, 11.3], [108.5, 10.95], [108.0, 10.7], [107.4, 10.45],
  [107.0, 10.4], [106.75, 10.15], [106.65, 9.75], [106.25, 9.4], [105.85, 9.1],
  [105.4, 8.7], [104.8, 8.56], [104.85, 9.2], [104.85, 9.7], [105.0, 10.1],
  [104.6, 10.45], [105.1, 10.9], [105.4, 10.95], [105.85, 10.95], [106.1, 11.1],
  [106.45, 11.3], [106.4, 11.7], [106.8, 12.1], [107.55, 12.35], [107.55, 12.8],
  [107.48, 13.5], [107.62, 14.0], [107.55, 14.7], [107.7, 15.2], [107.2, 15.75],
  [107.45, 16.1], [107.1, 16.3], [106.7, 16.6], [106.5, 17.0], [106.25, 17.3],
  [105.9, 17.75], [105.6, 18.2], [105.15, 18.7], [104.6, 19.0], [103.9, 19.3],
  [104.1, 19.7], [104.7, 20.0], [104.6, 20.4], [104.2, 20.65], [103.7, 20.7],
  [103.2, 20.9], [102.9, 21.3], [102.65, 21.7], [102.15, 21.95],
];

export const PHU_QUOC: [number, number][] = [
  [103.85, 10.42], [104.08, 10.4], [104.05, 10.05], [103.95, 9.98], [103.84, 10.15],
];

export const LAND = [MAINLAND, PHU_QUOC];

export type City = { name: string; province: string; lon: number; lat: number };

// Administrative centres of the 34 provincial-level units (from 1 July 2025).
export const CITIES: City[] = [
  { name: "Hà Nội", province: "Hà Nội", lon: 105.85, lat: 21.03 },
  { name: "Huế", province: "Huế", lon: 107.59, lat: 16.46 },
  { name: "Hạ Long", province: "Quảng Ninh", lon: 107.08, lat: 20.95 },
  { name: "Cao Bằng", province: "Cao Bằng", lon: 106.26, lat: 22.67 },
  { name: "Lạng Sơn", province: "Lạng Sơn", lon: 106.76, lat: 21.85 },
  { name: "Lai Châu", province: "Lai Châu", lon: 103.46, lat: 22.4 },
  { name: "Điện Biên Phủ", province: "Điện Biên", lon: 103.02, lat: 21.39 },
  { name: "Sơn La", province: "Sơn La", lon: 103.91, lat: 21.33 },
  { name: "Thanh Hóa", province: "Thanh Hóa", lon: 105.78, lat: 19.81 },
  { name: "Vinh", province: "Nghệ An", lon: 105.69, lat: 18.68 },
  { name: "Hà Tĩnh", province: "Hà Tĩnh", lon: 105.9, lat: 18.34 },
  { name: "Tuyên Quang", province: "Tuyên Quang", lon: 105.22, lat: 21.82 },
  { name: "Yên Bái", province: "Lào Cai", lon: 104.87, lat: 21.72 },
  { name: "Thái Nguyên", province: "Thái Nguyên", lon: 105.84, lat: 21.59 },
  { name: "Việt Trì", province: "Phú Thọ", lon: 105.4, lat: 21.32 },
  { name: "Bắc Giang", province: "Bắc Ninh", lon: 106.19, lat: 21.27 },
  { name: "Hưng Yên", province: "Hưng Yên", lon: 106.05, lat: 20.65 },
  { name: "Hải Phòng", province: "Hải Phòng", lon: 106.68, lat: 20.86 },
  { name: "Ninh Bình", province: "Ninh Bình", lon: 105.97, lat: 20.25 },
  { name: "Đồng Hới", province: "Quảng Trị", lon: 106.62, lat: 17.47 },
  { name: "Đà Nẵng", province: "Đà Nẵng", lon: 108.21, lat: 16.05 },
  { name: "Quảng Ngãi", province: "Quảng Ngãi", lon: 108.8, lat: 15.12 },
  { name: "Quy Nhơn", province: "Gia Lai", lon: 109.22, lat: 13.78 },
  { name: "Nha Trang", province: "Khánh Hòa", lon: 109.19, lat: 12.24 },
  { name: "Đà Lạt", province: "Lâm Đồng", lon: 108.44, lat: 11.94 },
  { name: "Buôn Ma Thuột", province: "Đắk Lắk", lon: 108.04, lat: 12.67 },
  { name: "TP. Hồ Chí Minh", province: "TP. Hồ Chí Minh", lon: 106.7, lat: 10.78 },
  { name: "Biên Hòa", province: "Đồng Nai", lon: 106.82, lat: 10.95 },
  { name: "Tân An", province: "Tây Ninh", lon: 106.41, lat: 10.54 },
  { name: "Cần Thơ", province: "Cần Thơ", lon: 105.78, lat: 10.03 },
  { name: "Vĩnh Long", province: "Vĩnh Long", lon: 105.97, lat: 10.25 },
  { name: "Mỹ Tho", province: "Đồng Tháp", lon: 106.36, lat: 10.36 },
  { name: "Cà Mau", province: "Cà Mau", lon: 105.15, lat: 9.18 },
  { name: "Rạch Giá", province: "An Giang", lon: 105.08, lat: 10.01 },
];
