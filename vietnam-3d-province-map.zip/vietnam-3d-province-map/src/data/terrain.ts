// Approximate elevation model of Vietnam (metres), built from the main relief
// features: Hoàng Liên Sơn, the north-west and north-east highlands, the
// Trường Sơn range, the Central Highlands plateaus, and the flat Red River and
// Mekong deltas. Stylised; it is not survey or DEM data.
import { MAINLAND } from "./vietnam";

type Pt = [number, number];

const clamp01 = (x: number) => Math.max(0, Math.min(1, x));
const smooth = (a: number, b: number, x: number) => {
  const t = clamp01((x - a) / (b - a));
  return t * t * (3 - 2 * t);
};

function distToSegment(p: Pt, a: Pt, b: Pt) {
  const k = Math.cos((16 * Math.PI) / 180);
  const px = p[0] * k, ax = a[0] * k, bx = b[0] * k;
  const dx = bx - ax, dy = b[1] - a[1];
  const t = clamp01(((px - ax) * dx + (p[1] - a[1]) * dy) / (dx * dx + dy * dy || 1));
  return Math.hypot(px - (ax + t * dx), p[1] - (a[1] + t * dy));
}

/** Gaussian ridge along a polyline. */
function ridge(p: Pt, line: Pt[], height: number, width: number) {
  let d = Infinity;
  for (let i = 0; i < line.length - 1; i++) d = Math.min(d, distToSegment(p, line[i], line[i + 1]));
  return height * Math.exp(-(d * d) / (2 * width * width));
}
const peak = (p: Pt, c: Pt, height: number, width: number) => ridge(p, [c, c], height, width);

// value noise for ruggedness
function hash(x: number, y: number) {
  const s = Math.sin(x * 127.1 + y * 311.7) * 43758.5453;
  return s - Math.floor(s);
}
function noise(x: number, y: number) {
  const xi = Math.floor(x), yi = Math.floor(y);
  const xf = x - xi, yf = y - yi;
  const u = xf * xf * (3 - 2 * xf), v = yf * yf * (3 - 2 * yf);
  const a = hash(xi, yi), b = hash(xi + 1, yi), c = hash(xi, yi + 1), d = hash(xi + 1, yi + 1);
  return a + (b - a) * u + (c - a) * v + (a - b - c + d) * u * v;
}
function fbm(x: number, y: number) {
  return noise(x, y) * 0.55 + noise(x * 2.1, y * 2.1) * 0.3 + noise(x * 4.3, y * 4.3) * 0.15;
}

// Coastline = the mainland outline from Móng Cái round to Hà Tiên.
const COAST = MAINLAND.slice(15, 51);

export function elevation(lon: number, lat: number): number {
  const p: Pt = [lon, lat];
  let e = 0;

  // North-west
  e = Math.max(e, ridge(p, [[103.3, 22.75], [103.8, 22.25], [104.6, 21.6]], 1800, 0.18)); // Hoàng Liên Sơn
  e = Math.max(e, ridge(p, [[102.3, 22.4], [102.9, 21.6], [103.3, 20.9]], 1500, 0.28)); // Laos border range
  e = Math.max(e, ridge(p, [[103.1, 21.7], [104.0, 21.2], [105.0, 20.6]], 750, 0.4)); // Sơn La – Mộc Châu plateau
  e = Math.max(e, peak(p, [103.77, 22.3], 2900, 0.08)); // Fansipan
  // North-east
  e = Math.max(e, ridge(p, [[104.6, 23.0], [105.5, 22.9], [106.6, 22.5]], 1000, 0.3)); // Hà Giang – Cao Bằng karst
  e = Math.max(e, peak(p, [104.81, 22.8], 2400, 0.12)); // Tây Côn Lĩnh
  e = Math.max(e, ridge(p, [[106.0, 22.1], [106.9, 21.7], [107.6, 21.45]], 750, 0.22)); // Đông Bắc arc
  e = Math.max(e, ridge(p, [[105.2, 22.2], [105.6, 21.9]], 900, 0.25)); // Tam Đảo / Bắc Kạn hills
  // Trường Sơn Bắc
  e = Math.max(e, ridge(p, [[104.0, 20.4], [104.4, 19.4], [104.9, 18.9], [105.6, 18.2], [106.2, 17.5], [106.8, 16.8]], 1700, 0.22));
  e = Math.max(e, peak(p, [104.18, 19.2], 2700, 0.12)); // Pu Xai Lai Leng
  // Central
  e = Math.max(e, ridge(p, [[106.8, 16.8], [107.2, 16.2], [107.7, 15.6], [107.9, 15.3]], 1500, 0.22));
  e = Math.max(e, ridge(p, [[107.5, 16.2], [108.1, 16.15]], 1100, 0.08)); // Bạch Mã – Hải Vân spur
  e = Math.max(e, peak(p, [107.97, 15.07], 2600, 0.22)); // Ngọc Linh massif
  e = Math.max(e, ridge(p, [[108.5, 15.0], [108.75, 13.6], [108.8, 12.9], [108.6, 11.9]], 1100, 0.18)); // eastern escarpment
  // Central Highlands plateaus
  const plateau = smooth(107.3, 107.75, lon) * (1 - smooth(108.55, 108.95, lon)) * smooth(11.4, 11.85, lat) * (1 - smooth(14.7, 15.2, lat));
  e = Math.max(e, 600 * plateau + 150 * fbm(lon * 3, lat * 3) * plateau);
  e = Math.max(e, peak(p, [108.45, 12.05], 1700, 0.25)); // Lâm Viên (Đà Lạt)
  e = Math.max(e, peak(p, [108.43, 12.4], 2400, 0.1)); // Chư Yang Sin
  e = Math.max(e, peak(p, [108.0, 11.6], 1050, 0.3)); // Di Linh
  e = Math.max(e, peak(p, [108.0, 14.0], 800, 0.3)); // Pleiku basalt

  // ruggedness
  const n = fbm(lon * 5, lat * 5);
  e *= 0.8 + 0.4 * n;

  // coast attenuation
  let dc = Infinity;
  for (let i = 0; i < COAST.length - 1; i++) dc = Math.min(dc, distToSegment(p, COAST[i], COAST[i + 1]));
  e *= 0.06 + 0.94 * smooth(0.02, 0.5, dc);

  // flat deltas
  const rr = ((lon - 106.2) / 0.8) ** 2 + ((lat - 20.65) / 0.55) ** 2;
  e *= 0.03 + 0.97 * smooth(0.55, 1.4, rr);
  const mekong = smooth(10.75, 11.3, lat) + (lon > 106.9 ? 1 : 0);
  e *= 0.02 + 0.98 * clamp01(mekong);

  // a few lowland landmarks
  e = Math.max(e, peak(p, [106.17, 11.38], 990, 0.04)); // Núi Bà Đen
  e = Math.max(e, peak(p, [105.92, 20.25], 220, 0.08)); // Ninh Bình karst
  e = Math.max(e, peak(p, [104.97, 10.55], 600, 0.07)); // Thất Sơn (An Giang)

  return Math.max(2, e + 25 * n);
}

const STOPS: [number, [number, number, number]][] = [
  [0, [0.27, 0.52, 0.33]],
  [80, [0.42, 0.62, 0.34]],
  [300, [0.63, 0.66, 0.38]],
  [700, [0.72, 0.6, 0.38]],
  [1300, [0.6, 0.45, 0.32]],
  [2000, [0.62, 0.56, 0.5]],
  [2800, [0.95, 0.95, 0.95]],
];

/** Hypsometric tint (r, g, b in 0–1) for an elevation in metres. */
export function terrainColor(e: number): [number, number, number] {
  for (let i = 1; i < STOPS.length; i++) {
    if (e <= STOPS[i][0]) {
      const [e0, c0] = STOPS[i - 1];
      const [e1, c1] = STOPS[i];
      const t = (e - e0) / (e1 - e0);
      return [c0[0] + (c1[0] - c0[0]) * t, c0[1] + (c1[1] - c0[1]) * t, c0[2] + (c1[2] - c0[2]) * t];
    }
  }
  return STOPS[STOPS.length - 1][1];
}

export const TERRAIN_LEGEND = [
  { label: "0–80 m", rgb: STOPS[0][1] },
  { label: "300 m", rgb: STOPS[2][1] },
  { label: "700 m", rgb: STOPS[3][1] },
  { label: "1,300 m", rgb: STOPS[4][1] },
  { label: "2,000 m", rgb: STOPS[5][1] },
  { label: "2,800 m+", rgb: STOPS[6][1] },
];
