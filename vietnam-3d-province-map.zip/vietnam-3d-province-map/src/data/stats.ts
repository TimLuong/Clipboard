// Mock-up figures per provincial-level unit (post-July-2025 boundaries).
// pop = million people, area = km², grdp = trillion VND, growth = % per year.
type Raw = { pop: number; area: number; grdp: number; growth: number };

const RAW: Record<string, Raw> = {
  "Hà Nội": { pop: 8.7, area: 3360, grdp: 1430, growth: 7.0 },
  "TP. Hồ Chí Minh": { pop: 14.0, area: 6772, grdp: 2700, growth: 7.2 },
  "Hải Phòng": { pop: 4.7, area: 3195, grdp: 680, growth: 10.5 },
  "Đà Nẵng": { pop: 3.1, area: 11860, grdp: 320, growth: 7.5 },
  "Huế": { pop: 1.2, area: 4947, grdp: 75, growth: 8.0 },
  "Cần Thơ": { pop: 4.2, area: 6360, grdp: 300, growth: 6.5 },
  "Quảng Ninh": { pop: 1.4, area: 6208, grdp: 330, growth: 10.2 },
  "Cao Bằng": { pop: 0.57, area: 6700, grdp: 25, growth: 6.0 },
  "Lạng Sơn": { pop: 0.8, area: 8310, grdp: 45, growth: 6.5 },
  "Lai Châu": { pop: 0.48, area: 9069, grdp: 27, growth: 7.0 },
  "Điện Biên": { pop: 0.65, area: 9540, grdp: 30, growth: 7.2 },
  "Sơn La": { pop: 1.3, area: 14110, grdp: 75, growth: 6.6 },
  "Thanh Hóa": { pop: 3.8, area: 11114, grdp: 300, growth: 9.0 },
  "Nghệ An": { pop: 3.5, area: 16486, grdp: 210, growth: 8.0 },
  "Hà Tĩnh": { pop: 1.3, area: 5994, grdp: 110, growth: 7.5 },
  "Tuyên Quang": { pop: 1.9, area: 13795, grdp: 85, growth: 7.0 },
  "Lào Cai": { pop: 1.8, area: 13257, grdp: 120, growth: 7.8 },
  "Thái Nguyên": { pop: 1.8, area: 8375, grdp: 170, growth: 7.0 },
  "Phú Thọ": { pop: 4.0, area: 9361, grdp: 380, growth: 8.0 },
  "Bắc Ninh": { pop: 3.6, area: 4718, grdp: 500, growth: 6.5 },
  "Hưng Yên": { pop: 3.6, area: 2514, grdp: 290, growth: 8.5 },
  "Ninh Bình": { pop: 4.4, area: 3942, grdp: 330, growth: 9.5 },
  "Quảng Trị": { pop: 1.9, area: 12700, grdp: 110, growth: 7.0 },
  "Quảng Ngãi": { pop: 1.9, area: 14832, grdp: 170, growth: 8.0 },
  "Gia Lai": { pop: 3.6, area: 21576, grdp: 230, growth: 7.0 },
  "Khánh Hòa": { pop: 2.2, area: 8555, grdp: 180, growth: 8.5 },
  "Lâm Đồng": { pop: 3.9, area: 24233, grdp: 300, growth: 7.5 },
  "Đắk Lắk": { pop: 3.3, area: 18096, grdp: 210, growth: 7.0 },
  "Đồng Nai": { pop: 4.5, area: 12737, grdp: 640, growth: 8.0 },
  "Tây Ninh": { pop: 3.3, area: 8536, grdp: 340, growth: 8.5 },
  "Vĩnh Long": { pop: 4.3, area: 6297, grdp: 260, growth: 6.5 },
  "Đồng Tháp": { pop: 4.4, area: 5938, grdp: 270, growth: 6.8 },
  "Cà Mau": { pop: 2.6, area: 7942, grdp: 140, growth: 6.0 },
  "An Giang": { pop: 4.9, area: 9888, grdp: 290, growth: 7.0 },
};

export type Stats = Raw & { density: number; perCapita: number };

export function statsFor(province: string): Stats {
  const r = RAW[province] ?? { pop: 0, area: 0, grdp: 0, growth: 0 };
  return {
    ...r,
    density: r.area ? (r.pop * 1e6) / r.area : 0, // people per km²
    perCapita: r.pop ? r.grdp / r.pop : 0, // million VND per person
  };
}

export type MetricKey = "pop" | "grdp" | "perCapita" | "density" | "growth";

export const METRICS: { key: MetricKey; label: string; short: string; fmt: (v: number) => string }[] = [
  { key: "pop", label: "Population", short: "Population", fmt: (v) => `${v.toFixed(2)} M` },
  { key: "grdp", label: "GRDP", short: "GRDP", fmt: (v) => `${Math.round(v).toLocaleString("en-US")} tn ₫` },
  { key: "perCapita", label: "GRDP per capita", short: "Per capita", fmt: (v) => `${Math.round(v).toLocaleString("en-US")} M ₫` },
  { key: "density", label: "Population density", short: "Density", fmt: (v) => `${Math.round(v).toLocaleString("en-US")} /km²` },
  { key: "growth", label: "GRDP growth", short: "Growth", fmt: (v) => `${v.toFixed(1)}%` },
];

// 5-step sequential ramp (light → dark), readable on the dark map stage.
export const RAMP = ["#d6ecf5", "#93c9e4", "#4fa3d3", "#2b72b8", "#1f3f8f"];

/** Quantile class breaks (5 classes) for a list of values. */
export function quantileBreaks(values: number[]): number[] {
  const s = [...values].sort((a, b) => a - b);
  return [0.2, 0.4, 0.6, 0.8].map((q) => s[Math.min(s.length - 1, Math.floor(q * s.length))]);
}

export function classOf(v: number, breaks: number[]) {
  let c = 0;
  while (c < breaks.length && v >= breaks[c]) c++;
  return c;
}
